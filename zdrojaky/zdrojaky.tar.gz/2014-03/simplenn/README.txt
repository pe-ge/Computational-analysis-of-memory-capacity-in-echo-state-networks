pocitanie ljap exponentu jednej NN,

pomocou vlastnych maticovych funkcii a vlastneho classu pre NN.

Pomale jak rit.
