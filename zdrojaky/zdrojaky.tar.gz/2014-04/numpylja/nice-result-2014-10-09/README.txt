=============
Instructions:
=============

Type
>>> make
to generate data and then
>>> make view
to view them. The result should look like
image vysledok-ako-boedecker.png

=====
Info:
=====

9.10.2014, 13:49
Script total time: 5m12s
sha1sum: c2506cd64fc16522bcfe1e8ade493d10ee0ccc0f  numpylja.py
