Ratanie ljapunoveho exponentu pre viacero NN,
ale zase pomocou vlastnych funkcii.

Spusta sa ./testljap.py
