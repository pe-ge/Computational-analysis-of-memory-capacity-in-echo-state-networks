=============
Dependencies:
=============

python3-scipy
python3-matplotlib

--

to install them on debian-like linux, type:

sudo apt-get install python3-scipy python3-matplotlib

========
Sha1sum:
========

d35fd2897084f9448caf9dd13c0b6acdc8655a76  mc.py

=====
Time:
=====

0.85s
