Nice result from 29.10.2014:

=============
Dependencies:
=============

python3-scipy
python3-matplotlib


===
sha1sums:
=========
706418248d2b6c25981b3d2197b0838bed81d752  mc2.py
b9b33893061770df0650b80c05219bc7209a1b60  nice.png


===========
Parameters:
===========

sigma=0.1
WI = unif(-0.1, 0.1)
input = unif(-1, 1)
W = normal(0, sigma)

